module lab_2 {
}